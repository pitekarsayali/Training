﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspAssig2
{
    public partial class loginForm : System.Web.UI.Page
    {
        public object Msg { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                if (this.Page.User.Identity.IsAuthenticated)
                {
                    FormsAuthentication.SignOut();
                    Response.Redirect("~/loginForm.aspx");
                }
            }

        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (FormsAuthentication.Authenticate(txtUserName.Text, txtUserPassword.Text))
            {
                FormsAuthentication.RedirectFromLoginPage(txtUserName.Text,true);
            }
            else
            {
                errLabel.Text = "Invalid User Name AND/OR Password";
            }
        }

        
    }
}