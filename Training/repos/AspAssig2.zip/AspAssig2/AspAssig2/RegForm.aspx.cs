﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AspAssig2
{
    public partial class RegForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                Dictionary<int, string> st = new Dictionary<int, string>();
                st.Add(1, "Maharashtra");
                st.Add(2, "Kerala");
                st.Add(3, "Telangana");

                state.DataSource = st;
                state.DataTextField = "Value";
                state.DataValueField = "Key";
                state.DataBind();


            }

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            EmpInfo emp = new EmpInfo();
            List<EmpInfo> emplist = new List<EmpInfo>();
            emp.userName = txtEmpName.Text;
            emp.mailid = txtemail.Text;
            emp.phone = txtboxPhone.Text;
            emp.state = state.Text;

            emplist.Add(emp);
            Session["lsa"] = emplist;

            List<EmpInfo> objlt = (List<EmpInfo>)Session["Key"];
            lblUname.Text =objlt.ToString();


            //if (un.ToString() == txtEmpName.Text)
            //    {
            //        lblUname.Text = un+"User ALreday";
            //    }
            //    else
            //    { 
            //        lblUname.Text = "Success";
            //   // Response.Redirect("LoginForm.aspx");
            
            //}
                
               



                


           
        }

        protected void state_SelectedIndexChanged(object sender, EventArgs e)
        {
            Dictionary<int, string> mh = new Dictionary<int, string>();
            mh.Add(1, "Mumbai");
            mh.Add(2, "Pune");
            mh.Add(3, "Kolhapur");
            mh.Add(4, "Solhapur");


            Dictionary<int, string> ker = new Dictionary<int, string>();
            ker.Add(1, "Kochi");
            ker.Add(2, "Kattam");

            Dictionary<int, string> tel = new Dictionary<int, string>();
            tel.Add(1, "Medak");
            tel.Add(2, "Madhapur");
            tel.Add(3, "Hitchcity");
            tel.Add(4, "JNTU");
            if (state.SelectedIndex == 0)
            {
                dropdwn.DataSource = mh;
                dropdwn.DataTextField = "Value";
                dropdwn.DataValueField = "Key";
                dropdwn.DataBind();

            }
            if (state.SelectedIndex == 1)
            {
                dropdwn.DataSource = ker;
                dropdwn.DataTextField = "Value";
                dropdwn.DataValueField = "Key";
                dropdwn.DataBind();
            }
            if (state.SelectedIndex == 2)
            {
                dropdwn.DataSource = tel;
                dropdwn.DataTextField = "Value";
                dropdwn.DataValueField = "Key";
                dropdwn.DataBind();
            }
        }
        protected void dropdwn_SelectedIndexChanged(object sender, EventArgs e) { }
        

    }
}

